/**
 * myscript.js
 */
 
 function toDateString(mili) {
 	let d = new Date(mili);
 	let year = d.getFullYear();
 	let month = make2digits(d.getMonth() + 1);
 	let date = make2digits(d.getDate());
 	let hour = make2digits(d.getHours());
 	let minute = make2digits(d.getMinutes());
 	let second = make2digits(d.getSeconds());
 	
 	return year + "-" + month + "-" + date
 		+ " " + hour + ":" + minute + ":" + second;
}

function make2digits(val){
	if (val < 10) { 
		val = "0" + val;
	}
	return val;
}

function isExtImage(file){
	let fileType = file.type;
	if(fileType.startsWith("image")){
		return true;
	}
	return false;
}